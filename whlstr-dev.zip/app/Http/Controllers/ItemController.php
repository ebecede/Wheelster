<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ItemController extends Controller
{
    public function addItem(Request $request)
    {
        // Handle adding item logic
    }

    public function viewItems()
    {
        // Handle viewing items logic
    }
}

